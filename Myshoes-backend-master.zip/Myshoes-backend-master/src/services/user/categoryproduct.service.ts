import { injectable } from "tsyringe";
import { Database } from "../../config/database";

@injectable()

export class categoryService{
    constructor(private db:Database){}
    async getdata():Promise<any>{
        try{
            const sql = "call getcategoriesdata";
            const [results] = await this.db.query(sql,[])
            if(Array.isArray(results) && results.length > 0){
                return results;
            }
            return null;
        }
        catch(error:any){
            throw new Error(error.message)
        }
    }

    async getdatabyid(id:any):Promise<any>{
        try{
            const sql = "call getcategoriesdatabyid(?)";
            const [results] = await this.db.query(sql,[id])
            if(Array.isArray(results) && results.length > 0){
                return results;
            }
            return null;
        }
        catch(error:any){
            throw new Error(error.message)
        }
    }
}