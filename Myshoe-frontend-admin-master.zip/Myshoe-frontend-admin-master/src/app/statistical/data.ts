export var multi = [
    {
      "name": "doanh thu",
      "series": [
        {
          "name": "1",
          "value": 62000000
        },
        {
          "name": "2",
          "value": 0
        },
        {
          "name": "3",
          "value": 89400000
        },
        {
          "name": "4",
          "value": 99400000
        },
        {
          "name": "5",
          "value": 0
        },
        {
          "name": "6",
          "value": 0
        },
        {
          "name": "7",
          "value": 0
        },
        {
          "name": "8",
          "value": 0
        },
        {
          "name": "9",
          "value": 0
        },
        {
          "name": "10",
          "value": 0
        },
        {
          "name": "11",
          "value": 0
        },
        {
          "name": "12",
          "value": 0
        }
      ]
    },
  ];

  export var single = [
    {
      "name": "Đơn hàng chờ duyệt",
      "value": 8940000
    },
    {
      "name": "Đơn hàng đang vận chuyển",
      "value": 5000000
    },
    {
      "name": "Đơn hàng đã hủy",
      "value": 7200000
    },
      {
      "name": "Đơn hàng đã giao",
      "value": 6200000
    }
  ];

  